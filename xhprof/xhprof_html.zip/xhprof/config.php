<?php
/*
 * Set the absolute paths on your system
 */
define('ERROR_FILE', 'd:/wamp/logs/xhprof_dot_errfile.log');
define('TMP_DIRECTORY', 'd:/wamp/tmp/xhprof/tmp/');
define('DOT_BINARY', 'c:/Program Files/Grafika/Graphviz/bin/dot.exe');
?>
